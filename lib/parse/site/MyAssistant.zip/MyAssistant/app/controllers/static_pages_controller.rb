class StaticPagesController < ApplicationController
end
