require 'rails_helper'

RSpec.describe ShedulesController, :type => :controller do

end
